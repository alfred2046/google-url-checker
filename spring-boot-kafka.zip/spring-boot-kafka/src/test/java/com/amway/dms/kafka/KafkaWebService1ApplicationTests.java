package com.amway.dms.kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaWebService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
