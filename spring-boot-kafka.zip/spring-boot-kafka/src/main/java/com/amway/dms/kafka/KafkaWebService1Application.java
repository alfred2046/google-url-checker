package com.amway.dms.kafka;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;

@SpringBootApplication
public class KafkaWebService1Application implements ApplicationRunner{

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	public void sendMessage(String msg){
		kafkaTemplate.send("quickstart-events", msg);
	}

	public static void main(String[] args) {
		SpringApplication.run(KafkaWebService1Application.class, args);
	}

	@KafkaListener(topics = "quickstart-events", groupId = "g7")
	public void listen(ConsumerRecords<?, ?> consumerRecords){
		System.out.println(consumerRecords.count());
		/*for (ConsumerRecord<String, String> record : consumerRecords){
			log.info("Key: " + record.key() + ", Value: " + record.value());
			log.info("Partition: " + record.partition() + ", Offset:" + record.offset());
		}*/
	}
    /*public void listen(String message){
        System.out.println("Received Message in group - g7: " + message);
    }*/

	@Override
	public void run(ApplicationArguments args) throws Exception {
		sendMessage("Welcome to Spring Boot for Apache Kafka");
	}

}
